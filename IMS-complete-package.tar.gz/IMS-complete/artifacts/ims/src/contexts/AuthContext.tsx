import { createContext, useContext, useState, useEffect, type ReactNode } from "react";

interface AuthUser {
  username: string;
  role: "admin" | "employee";
}

interface AuthContextType {
  user: AuthUser | null;
  login: (username: string, password: string) => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

const USERS = [
  { username: "admin", password: "admin123", role: "admin" as const },
  { username: "employee", password: "emp123", role: "employee" as const },
];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(() => {
    try {
      const stored = localStorage.getItem("ims_user");
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  const login = (username: string, password: string): boolean => {
    const found = USERS.find((u) => u.username === username && u.password === password);
    if (found) {
      const authUser: AuthUser = { username: found.username, role: found.role };
      setUser(authUser);
      localStorage.setItem("ims_user", JSON.stringify(authUser));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("ims_user");
  };

  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
