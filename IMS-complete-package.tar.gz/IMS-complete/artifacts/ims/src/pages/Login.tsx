import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Eye, EyeOff, Lock, User, Sparkles } from "lucide-react";

export default function Login() {
  const { login } = useAuth();
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    await new Promise((r) => setTimeout(r, 400));
    const ok = login(username, password);
    setLoading(false);
    if (ok) setLocation("/dashboard");
    else setError("Invalid username or password");
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden"
      style={{ background: "linear-gradient(135deg, #0f0c29 0%, #1a1054 35%, #24243e 70%, #0d1b4b 100%)" }}>

      {/* Decorative blobs */}
      <div className="absolute top-0 left-0 h-96 w-96 rounded-full opacity-20 blur-3xl"
        style={{ background: "radial-gradient(circle, #7c3aed, transparent)" }} />
      <div className="absolute bottom-0 right-0 h-96 w-96 rounded-full opacity-20 blur-3xl"
        style={{ background: "radial-gradient(circle, #06b6d4, transparent)" }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-72 w-72 rounded-full opacity-10 blur-3xl"
        style={{ background: "radial-gradient(circle, #f59e0b, transparent)" }} />

      <div className="w-full max-w-sm relative z-10 space-y-7">
        {/* Logo + Title */}
        <div className="text-center space-y-4">
          <div className="inline-flex h-20 w-20 items-center justify-center rounded-3xl shadow-2xl shadow-violet-500/40 relative"
            style={{ background: "linear-gradient(135deg, #7c3aed 0%, #4f46e5 50%, #2563eb 100%)" }}>
            <span className="text-2xl font-black text-white tracking-tighter">IMS</span>
            <Sparkles className="absolute -top-1.5 -right-1.5 h-5 w-5 text-amber-400" />
          </div>
          <div>
            <h1 className="text-3xl font-black text-white tracking-tight">Interior Management</h1>
            <p className="text-sm text-white/50 mt-1">Sign in to your workspace</p>
          </div>
        </div>

        {/* Card */}
        <div className="rounded-3xl border border-white/10 p-7 shadow-2xl"
          style={{ background: "rgba(255,255,255,0.06)", backdropFilter: "blur(24px)" }}>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label className="text-white/70 text-xs font-semibold uppercase tracking-wider">Username</Label>
              <div className="relative">
                <User className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40" />
                <Input
                  className="pl-10 bg-white/8 border-white/15 text-white placeholder:text-white/30 focus:border-violet-400 focus:ring-violet-400/20 rounded-xl h-11"
                  placeholder="admin"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-white/70 text-xs font-semibold uppercase tracking-wider">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40" />
                <Input
                  type={showPw ? "text" : "password"}
                  className="pl-10 pr-10 bg-white/8 border-white/15 text-white placeholder:text-white/30 focus:border-violet-400 focus:ring-violet-400/20 rounded-xl h-11"
                  placeholder="admin123"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPw((v) => !v)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/70 transition-colors"
                >
                  {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 rounded-xl bg-red-500/15 border border-red-500/30 px-3.5 py-2.5">
                <div className="h-1.5 w-1.5 rounded-full bg-red-400 shrink-0" />
                <p className="text-sm text-red-300">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full h-11 rounded-xl text-sm font-bold text-white shadow-lg shadow-violet-500/30 transition-all hover:shadow-violet-500/50 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed"
              style={{ background: "linear-gradient(135deg, #7c3aed 0%, #4f46e5 50%, #2563eb 100%)" }}
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                  Signing in…
                </span>
              ) : "Sign In"}
            </button>
          </form>
        </div>

        {/* Demo credentials */}
        <div className="rounded-2xl border border-white/8 px-4 py-3"
          style={{ background: "rgba(255,255,255,0.04)" }}>
          <p className="text-center text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">Demo Credentials</p>
          <div className="flex justify-center gap-6 text-xs">
            <span className="text-white/50"><span className="text-violet-400 font-semibold">admin</span> / admin123</span>
            <span className="text-white/50"><span className="text-cyan-400 font-semibold">employee</span> / emp123</span>
          </div>
        </div>
      </div>
    </div>
  );
}
