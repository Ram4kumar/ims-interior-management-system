import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/PageHeader";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Settings as SettingsIcon, User, Shield, Database, Palette } from "lucide-react";

export default function Settings() {
  const { user } = useAuth();

  return (
    <div>
      <PageHeader
        title="Settings"
        subtitle="System configuration & account info"
        icon={SettingsIcon}
        gradient="bg-gradient-to-br from-slate-600 via-gray-600 to-zinc-700"
      />

      <div className="max-w-2xl space-y-5">
        {/* Profile */}
        <Card className="overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-violet-500 to-indigo-600" />
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <User className="h-4 w-4 text-violet-500" /> Profile
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 to-indigo-600 text-white text-xl font-black uppercase shadow-lg shadow-violet-500/30">
                {user?.username?.slice(0, 2)}
              </div>
              <div>
                <p className="font-bold text-foreground text-lg">{user?.username}</p>
                <p className="text-sm text-muted-foreground capitalize">{user?.role} Account</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Username</Label>
                <Input value={user?.username ?? ""} disabled className="bg-muted" />
              </div>
              <div className="space-y-1.5">
                <Label>Role</Label>
                <Input value={user?.role ?? ""} disabled className="bg-muted capitalize" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Demo Credentials */}
        <Card className="overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-amber-500 to-orange-500" />
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Shield className="h-4 w-4 text-amber-500" /> Demo Credentials
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="rounded-xl bg-muted p-4 space-y-3">
              <div className="flex items-center gap-4">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-indigo-600 text-white text-xs font-bold">AD</div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-foreground">Admin</p>
                  <p className="text-xs text-muted-foreground font-mono">admin / admin123</p>
                </div>
                <span className="text-xs bg-violet-100 text-violet-700 dark:bg-violet-950/50 dark:text-violet-300 px-2 py-0.5 rounded-full font-medium">Full Access</span>
              </div>
              <div className="border-t border-border pt-3 flex items-center gap-4">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-sky-500 to-cyan-600 text-white text-xs font-bold">EM</div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-foreground">Employee</p>
                  <p className="text-xs text-muted-foreground font-mono">employee / emp123</p>
                </div>
                <span className="text-xs bg-sky-100 text-sky-700 dark:bg-sky-950/50 dark:text-sky-300 px-2 py-0.5 rounded-full font-medium">Limited</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* System Info */}
        <Card className="overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-emerald-500 to-teal-600" />
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Database className="h-4 w-4 text-emerald-500" /> System Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-0 divide-y divide-border">
              {[
                { label: "System", value: "IMS — Interior Management System" },
                { label: "Stack", value: "React + Express + PostgreSQL" },
                { label: "Frontend", value: "React 19, Vite, Tailwind CSS v4" },
                { label: "Version", value: "1.0.0" },
                { label: "Environment", value: "Development" },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between items-center py-3 text-sm">
                  <span className="text-muted-foreground">{label}</span>
                  <span className="font-semibold text-foreground">{value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Appearance */}
        <Card className="overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-pink-500 to-rose-500" />
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Palette className="h-4 w-4 text-pink-500" /> Appearance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">Toggle between light and dark mode using the <span className="font-semibold text-foreground">sun/moon icon</span> in the top navigation bar. Your preference is applied instantly.</p>
            <div className="mt-3 grid grid-cols-2 gap-3">
              <div className="rounded-xl border-2 border-violet-300 dark:border-violet-600 overflow-hidden">
                <div className="h-12 bg-gradient-to-br from-white to-slate-100 flex items-center justify-center">
                  <span className="text-xs font-semibold text-slate-600">Light Mode</span>
                </div>
              </div>
              <div className="rounded-xl border-2 border-violet-300 dark:border-violet-500 overflow-hidden">
                <div className="h-12 bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center">
                  <span className="text-xs font-semibold text-slate-200">Dark Mode</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
