import { useState } from "react";
import { useListInvoices, useCreateInvoice, useUpdateInvoice, useDeleteInvoice, useListClients, useListProjects, getListInvoicesQueryKey } from "@workspace/api-client-react";
import type { Invoice } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StatusBadge } from "@/components/StatusBadge";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency, formatDate } from "@/lib/utils";
import { FileText, Plus, Pencil, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";

const TABS = ["all", "pending", "paid", "overdue", "cancelled"];

const TAB_STYLES: Record<string, string> = {
  all: "from-blue-500 to-indigo-600",
  pending: "from-amber-500 to-orange-500",
  paid: "from-emerald-500 to-teal-600",
  overdue: "from-red-500 to-rose-600",
  cancelled: "from-gray-400 to-gray-500",
};

type FormData = { clientId: string; projectId: string; amount: string; taxRate: string; status: string; dueDate: string; issueDate: string; notes: string };
const empty: FormData = { clientId: "", projectId: "", amount: "", taxRate: "18", status: "pending", dueDate: "", issueDate: "", notes: "" };

export default function Invoices() {
  const qc = useQueryClient();
  const [tab, setTab] = useState("all");
  const { data: invoices, isLoading } = useListInvoices({ status: tab === "all" ? undefined : tab });
  const { data: clients } = useListClients();
  const { data: projects } = useListProjects();
  const createMut = useCreateInvoice();
  const updateMut = useUpdateInvoice();
  const deleteMut = useDeleteInvoice();
  const [dialog, setDialog] = useState<{ open: boolean; editing: Invoice | null }>({ open: false, editing: null });
  const [form, setForm] = useState<FormData>(empty);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const invalidate = () => qc.invalidateQueries({ queryKey: getListInvoicesQueryKey() });
  const openCreate = () => { setForm(empty); setDialog({ open: true, editing: null }); };
  const openEdit = (inv: Invoice) => {
    setForm({ clientId: String(inv.clientId), projectId: inv.projectId ? String(inv.projectId) : "", amount: String(inv.amount), taxRate: String(inv.taxRate), status: inv.status, dueDate: inv.dueDate, issueDate: inv.issueDate, notes: inv.notes });
    setDialog({ open: true, editing: inv });
  };

  const handleSave = () => {
    const payload = { clientId: parseInt(form.clientId), projectId: form.projectId ? parseInt(form.projectId) : null, amount: parseFloat(form.amount) || 0, taxRate: parseFloat(form.taxRate) || 18, status: form.status as Invoice["status"], dueDate: form.dueDate, issueDate: form.issueDate, notes: form.notes };
    if (dialog.editing) {
      updateMut.mutate({ id: dialog.editing.id, data: payload }, { onSuccess: () => { invalidate(); setDialog({ open: false, editing: null }); } });
    } else {
      createMut.mutate({ data: payload }, { onSuccess: () => { invalidate(); setDialog({ open: false, editing: null }); } });
    }
  };

  const setField = (k: keyof FormData) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setForm((p) => ({ ...p, [k]: e.target.value }));
  const setSelect = (k: keyof FormData) => (v: string) => setForm((p) => ({ ...p, [k]: v }));

  const totalPending = (invoices ?? []).filter((i) => i.status === "pending" || i.status === "overdue").reduce((s, i) => s + i.totalAmount, 0);
  const totalPaid = (invoices ?? []).filter((i) => i.status === "paid").reduce((s, i) => s + i.totalAmount, 0);

  return (
    <div>
      <PageHeader
        title="Invoices"
        subtitle="Manage billing & payment status"
        icon={FileText}
        gradient="bg-gradient-to-br from-blue-500 via-indigo-500 to-violet-600"
        stats={[
          { label: "Total Invoices", value: invoices?.length ?? 0 },
          { label: "Collected", value: formatCurrency(totalPaid) },
          { label: "Outstanding", value: formatCurrency(totalPending) },
        ]}
        action={
          <Button onClick={openCreate} className="bg-white/20 hover:bg-white/30 text-white border-0 backdrop-blur-sm shadow-none">
            <Plus className="mr-2 h-4 w-4" /> Generate Invoice
          </Button>
        }
      />

      {/* Tabs */}
      <div className="flex gap-2 mb-5 flex-wrap">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={cn("px-4 py-2 text-sm font-semibold rounded-xl capitalize transition-all shadow-sm",
              tab === t
                ? `bg-gradient-to-r ${TAB_STYLES[t]} text-white shadow-md scale-[1.02]`
                : "bg-card border border-border text-muted-foreground hover:text-foreground hover:border-primary/30"
            )}>
            {t}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-14 rounded-xl" />)}</div>
      ) : (invoices ?? []).length === 0 ? (
        <EmptyState icon={FileText} title="No invoices found" description="Generate your first invoice"
          action={<Button onClick={openCreate}><Plus className="mr-2 h-4 w-4" />Generate Invoice</Button>} />
      ) : (
        <div className="rounded-2xl border border-border bg-card shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/50">
                  <th className="text-left px-5 py-3.5 font-semibold text-muted-foreground">Invoice #</th>
                  <th className="text-left px-5 py-3.5 font-semibold text-muted-foreground">Client</th>
                  <th className="text-left px-5 py-3.5 font-semibold text-muted-foreground">Project</th>
                  <th className="text-left px-5 py-3.5 font-semibold text-muted-foreground">Issued</th>
                  <th className="text-left px-5 py-3.5 font-semibold text-muted-foreground">Due</th>
                  <th className="text-left px-5 py-3.5 font-semibold text-muted-foreground">Status</th>
                  <th className="text-right px-5 py-3.5 font-semibold text-muted-foreground">Total</th>
                  <th className="px-4 py-3.5"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {(invoices ?? []).map((inv) => (
                  <tr key={inv.id} className={cn("hover:bg-muted/30 transition-colors group", inv.status === "overdue" && "bg-red-50/40 dark:bg-red-950/10")}>
                    <td className="px-5 py-3.5">
                      <span className="font-mono text-xs font-bold bg-muted px-2 py-0.5 rounded-md text-foreground">{inv.invoiceNumber}</span>
                    </td>
                    <td className="px-5 py-3.5 font-medium text-foreground">{inv.clientName}</td>
                    <td className="px-5 py-3.5 text-muted-foreground">{inv.projectName ?? "—"}</td>
                    <td className="px-5 py-3.5 text-muted-foreground whitespace-nowrap">{formatDate(inv.issueDate)}</td>
                    <td className="px-5 py-3.5 text-muted-foreground whitespace-nowrap">{formatDate(inv.dueDate)}</td>
                    <td className="px-5 py-3.5"><StatusBadge status={inv.status} /></td>
                    <td className="px-5 py-3.5 text-right font-bold text-foreground">{formatCurrency(inv.totalAmount)}</td>
                    <td className="px-4 py-3.5">
                      <div className="flex gap-1 justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => openEdit(inv)} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>
                        <button onClick={() => setDeleteId(inv.id)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-muted-foreground hover:text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <Dialog open={dialog.open} onOpenChange={(open) => setDialog({ open, editing: null })}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className="h-6 w-1 rounded-full bg-gradient-to-b from-blue-500 to-indigo-600" />
              {dialog.editing ? "Edit Invoice" : "Generate Invoice"}
            </DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5 col-span-2 sm:col-span-1">
              <Label>Client</Label>
              <Select value={form.clientId} onValueChange={setSelect("clientId")}>
                <SelectTrigger><SelectValue placeholder="Select client" /></SelectTrigger>
                <SelectContent>{(clients ?? []).map((c) => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5 col-span-2 sm:col-span-1">
              <Label>Project (optional)</Label>
              <Select value={form.projectId || "_none"} onValueChange={(v) => setSelect("projectId")(v === "_none" ? "" : v)}>
                <SelectTrigger><SelectValue placeholder="No project" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="_none">No project</SelectItem>
                  {(projects ?? []).map((p) => <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Amount (INR)</Label><Input type="number" value={form.amount} onChange={setField("amount")} placeholder="0" /></div>
            <div className="space-y-1.5"><Label>GST Rate (%)</Label><Input type="number" value={form.taxRate} onChange={setField("taxRate")} placeholder="18" /></div>
            <div className="space-y-1.5"><Label>Issue Date</Label><Input type="date" value={form.issueDate} onChange={setField("issueDate")} /></div>
            <div className="space-y-1.5"><Label>Due Date</Label><Input type="date" value={form.dueDate} onChange={setField("dueDate")} /></div>
            <div className="space-y-1.5">
              <Label>Status</Label>
              <Select value={form.status} onValueChange={setSelect("status")}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="overdue">Overdue</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5 col-span-2"><Label>Notes</Label><Textarea value={form.notes} onChange={setField("notes")} rows={2} placeholder="Invoice notes…" /></div>
            {form.amount && form.taxRate && (
              <div className="col-span-2 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/30 border border-blue-200 dark:border-blue-800 p-4 text-sm space-y-1.5">
                <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span className="font-medium">{formatCurrency(parseFloat(form.amount) || 0)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">GST ({form.taxRate}%)</span><span className="font-medium">{formatCurrency((parseFloat(form.amount) || 0) * (parseFloat(form.taxRate) || 0) / 100)}</span></div>
                <div className="flex justify-between font-bold text-base border-t border-blue-200 dark:border-blue-800 pt-1.5"><span>Total</span><span className="text-blue-700 dark:text-blue-300">{formatCurrency((parseFloat(form.amount) || 0) * (1 + (parseFloat(form.taxRate) || 0) / 100))}</span></div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialog({ open: false, editing: null })}>Cancel</Button>
            <Button onClick={handleSave} disabled={createMut.isPending || updateMut.isPending}
              className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white border-0">
              {dialog.editing ? "Update" : "Generate"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={deleteId !== null} onOpenChange={() => setDeleteId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Delete Invoice</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">This will permanently delete this invoice record.</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteId(null)}>Cancel</Button>
            <Button variant="destructive" onClick={() => { if (deleteId) deleteMut.mutate({ id: deleteId }, { onSuccess: () => { invalidate(); setDeleteId(null); } }); }} disabled={deleteMut.isPending}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
