import { useState } from "react";
import { useListClients, useCreateClient, useUpdateClient, useDeleteClient, getListClientsQueryKey } from "@workspace/api-client-react";
import type { Client, ClientInput } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency, formatDate } from "@/lib/utils";
import { Users, Plus, Search, Pencil, Trash2, Phone, Mail, MapPin, IndianRupee } from "lucide-react";

type FormData = { name: string; phone: string; email: string; address: string; requirements: string; budget: string };
const empty: FormData = { name: "", phone: "", email: "", address: "", requirements: "", budget: "" };

const AVATAR_GRADIENTS = [
  "from-violet-500 to-indigo-600",
  "from-sky-500 to-cyan-600",
  "from-emerald-500 to-teal-600",
  "from-pink-500 to-rose-600",
  "from-amber-500 to-orange-500",
  "from-blue-500 to-indigo-600",
];

export default function Clients() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const { data: clients, isLoading } = useListClients({ search: search || undefined });
  const createMut = useCreateClient();
  const updateMut = useUpdateClient();
  const deleteMut = useDeleteClient();

  const [dialog, setDialog] = useState<{ open: boolean; editing: Client | null }>({ open: false, editing: null });
  const [form, setForm] = useState<FormData>(empty);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const openCreate = () => { setForm(empty); setDialog({ open: true, editing: null }); };
  const openEdit = (c: Client) => {
    setForm({ name: c.name, phone: c.phone, email: c.email, address: c.address, requirements: c.requirements, budget: String(c.budget) });
    setDialog({ open: true, editing: c });
  };

  const invalidate = () => qc.invalidateQueries({ queryKey: getListClientsQueryKey() });

  const handleSave = () => {
    const payload = { ...form, budget: parseFloat(form.budget) || 0 };
    if (dialog.editing) {
      updateMut.mutate({ id: dialog.editing.id, data: payload }, { onSuccess: () => { invalidate(); setDialog({ open: false, editing: null }); } });
    } else {
      createMut.mutate({ data: payload as ClientInput }, { onSuccess: () => { invalidate(); setDialog({ open: false, editing: null }); } });
    }
  };

  const setField = (k: keyof FormData) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((p) => ({ ...p, [k]: e.target.value }));

  const total = clients?.length ?? 0;

  return (
    <div>
      <PageHeader
        title="Clients"
        subtitle="Manage your client relationships"
        icon={Users}
        gradient="bg-gradient-to-br from-sky-500 via-cyan-500 to-teal-600"
        stats={[
          { label: "Total Clients", value: total },
          { label: "Active", value: total },
          { label: "This Month", value: clients?.filter(c => new Date(c.createdAt) > new Date(Date.now() - 30 * 86400000)).length ?? 0 },
        ]}
        action={
          <Button onClick={openCreate} className="bg-white/20 hover:bg-white/30 text-white border-0 backdrop-blur-sm shadow-none">
            <Plus className="mr-2 h-4 w-4" /> Add Client
          </Button>
        }
      />

      {/* Search */}
      <div className="relative mb-5 max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input className="pl-9 rounded-xl" placeholder="Search clients…" value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-48 rounded-2xl" />)}
        </div>
      ) : (clients ?? []).length === 0 ? (
        <EmptyState icon={Users} title="No clients yet" description="Add your first client to get started"
          action={<Button onClick={openCreate}><Plus className="mr-2 h-4 w-4" />Add Client</Button>} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {(clients ?? []).map((c, idx) => {
            const grad = AVATAR_GRADIENTS[idx % AVATAR_GRADIENTS.length];
            return (
              <div key={c.id} className="rounded-2xl border border-border bg-card shadow-sm hover:shadow-lg transition-all duration-200 group overflow-hidden">
                {/* Color strip */}
                <div className={`h-1.5 bg-gradient-to-r ${grad}`} />
                <div className="p-5">
                  <div className="flex items-start justify-between gap-2 mb-4">
                    <div className="flex items-center gap-3">
                      <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${grad} text-white font-bold text-sm shadow-md`}>
                        {c.name.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <h3 className="font-bold text-foreground leading-tight">{c.name}</h3>
                        <p className="text-xs text-muted-foreground mt-0.5">{formatDate(c.createdAt)}</p>
                      </div>
                    </div>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => openEdit(c)} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"><Pencil className="h-3.5 w-3.5" /></button>
                      <button onClick={() => setDeleteId(c.id)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-muted-foreground hover:text-red-600 transition-colors"><Trash2 className="h-3.5 w-3.5" /></button>
                    </div>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2.5 text-muted-foreground"><Phone className="h-3.5 w-3.5 shrink-0 text-sky-500" /><span className="truncate">{c.phone}</span></div>
                    <div className="flex items-center gap-2.5 text-muted-foreground"><Mail className="h-3.5 w-3.5 shrink-0 text-violet-500" /><span className="truncate">{c.email}</span></div>
                    <div className="flex items-center gap-2.5 text-muted-foreground"><MapPin className="h-3.5 w-3.5 shrink-0 text-emerald-500" /><span className="truncate">{c.address}</span></div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-border flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Budget</span>
                    <span className="font-bold text-sm text-foreground">{formatCurrency(c.budget)}</span>
                  </div>

                  {c.requirements && (
                    <p className="mt-2 text-xs text-muted-foreground line-clamp-2 bg-muted/50 rounded-lg px-2.5 py-2">{c.requirements}</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={dialog.open} onOpenChange={(open) => setDialog({ open, editing: null })}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className="h-6 w-1 rounded-full bg-gradient-to-b from-sky-500 to-cyan-600" />
              {dialog.editing ? "Edit Client" : "Add Client"}
            </DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5 col-span-2 sm:col-span-1">
              <Label>Name</Label>
              <Input value={form.name} onChange={setField("name")} placeholder="Full name" />
            </div>
            <div className="space-y-1.5 col-span-2 sm:col-span-1">
              <Label>Phone</Label>
              <Input value={form.phone} onChange={setField("phone")} placeholder="Mobile number" />
            </div>
            <div className="space-y-1.5 col-span-2 sm:col-span-1">
              <Label>Email</Label>
              <Input type="email" value={form.email} onChange={setField("email")} placeholder="Email address" />
            </div>
            <div className="space-y-1.5 col-span-2 sm:col-span-1">
              <Label>Budget (INR)</Label>
              <Input type="number" value={form.budget} onChange={setField("budget")} placeholder="0" />
            </div>
            <div className="space-y-1.5 col-span-2">
              <Label>Address</Label>
              <Input value={form.address} onChange={setField("address")} placeholder="Full address" />
            </div>
            <div className="space-y-1.5 col-span-2">
              <Label>Requirements</Label>
              <Textarea value={form.requirements} onChange={setField("requirements")} placeholder="Project requirements…" rows={3} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialog({ open: false, editing: null })}>Cancel</Button>
            <Button onClick={handleSave} disabled={createMut.isPending || updateMut.isPending}
              className="bg-gradient-to-r from-sky-500 to-cyan-600 text-white border-0">
              {dialog.editing ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={deleteId !== null} onOpenChange={() => setDeleteId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Delete Client</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">This will permanently delete this client. This cannot be undone.</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteId(null)}>Cancel</Button>
            <Button variant="destructive" onClick={() => { if (deleteId) deleteMut.mutate({ id: deleteId }, { onSuccess: () => { invalidate(); setDeleteId(null); } }); }} disabled={deleteMut.isPending}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
