import { useState } from "react";
import { useListProjects, useCreateProject, useUpdateProject, useDeleteProject, useListClients, getListProjectsQueryKey } from "@workspace/api-client-react";
import type { Project } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StatusBadge } from "@/components/StatusBadge";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency, formatDate } from "@/lib/utils";
import { FolderKanban, Plus, Pencil, Trash2, MapPin, Calendar, Users, IndianRupee } from "lucide-react";
import { cn } from "@/lib/utils";

type FormData = {
  name: string; clientId: string; status: string; startDate: string;
  endDate: string; budget: string; location: string; notes: string; assignedEmployees: string;
};
const empty: FormData = { name: "", clientId: "", status: "pending", startDate: "", endDate: "", budget: "", location: "", notes: "", assignedEmployees: "" };
const TABS = ["all", "pending", "ongoing", "completed"];

const TAB_STYLES: Record<string, string> = {
  all: "from-violet-500 to-indigo-600",
  pending: "from-amber-500 to-orange-500",
  ongoing: "from-blue-500 to-cyan-600",
  completed: "from-emerald-500 to-teal-600",
};

export default function Projects() {
  const qc = useQueryClient();
  const [tab, setTab] = useState("all");
  const { data: projects, isLoading } = useListProjects({ status: tab === "all" ? undefined : tab });
  const { data: clients } = useListClients();
  const createMut = useCreateProject();
  const updateMut = useUpdateProject();
  const deleteMut = useDeleteProject();
  const [dialog, setDialog] = useState<{ open: boolean; editing: Project | null }>({ open: false, editing: null });
  const [form, setForm] = useState<FormData>(empty);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const invalidate = () => qc.invalidateQueries({ queryKey: getListProjectsQueryKey() });

  const openCreate = () => { setForm(empty); setDialog({ open: true, editing: null }); };
  const openEdit = (p: Project) => {
    setForm({ name: p.name, clientId: String(p.clientId), status: p.status, startDate: p.startDate, endDate: p.endDate, budget: String(p.budget), location: p.location, notes: p.notes, assignedEmployees: p.assignedEmployees.join(", ") });
    setDialog({ open: true, editing: p });
  };

  const handleSave = () => {
    const payload = { name: form.name, clientId: parseInt(form.clientId), status: form.status as "pending" | "ongoing" | "completed", startDate: form.startDate, endDate: form.endDate, budget: parseFloat(form.budget) || 0, location: form.location, notes: form.notes, assignedEmployees: form.assignedEmployees ? form.assignedEmployees.split(",").map((s) => s.trim()).filter(Boolean) : [] };
    if (dialog.editing) {
      updateMut.mutate({ id: dialog.editing.id, data: payload }, { onSuccess: () => { invalidate(); setDialog({ open: false, editing: null }); } });
    } else {
      createMut.mutate({ data: payload }, { onSuccess: () => { invalidate(); setDialog({ open: false, editing: null }); } });
    }
  };

  const setField = (k: keyof FormData) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setForm((p) => ({ ...p, [k]: e.target.value }));
  const setSelect = (k: keyof FormData) => (v: string) => setForm((p) => ({ ...p, [k]: v }));

  const statusCounts = { pending: projects?.filter(p => p.status === "pending").length ?? 0, ongoing: projects?.filter(p => p.status === "ongoing").length ?? 0, completed: projects?.filter(p => p.status === "completed").length ?? 0 };

  return (
    <div>
      <PageHeader
        title="Projects"
        subtitle="Track all your interior projects"
        icon={FolderKanban}
        gradient="bg-gradient-to-br from-emerald-500 via-teal-500 to-cyan-600"
        stats={[
          { label: "Pending", value: statusCounts.pending },
          { label: "Ongoing", value: statusCounts.ongoing },
          { label: "Completed", value: statusCounts.completed },
        ]}
        action={
          <Button onClick={openCreate} className="bg-white/20 hover:bg-white/30 text-white border-0 backdrop-blur-sm shadow-none">
            <Plus className="mr-2 h-4 w-4" /> New Project
          </Button>
        }
      />

      {/* Tabs */}
      <div className="flex gap-2 mb-5 flex-wrap">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={cn("px-4 py-2 text-sm font-semibold rounded-xl capitalize transition-all shadow-sm",
              tab === t
                ? `bg-gradient-to-r ${TAB_STYLES[t]} text-white shadow-md scale-[1.02]`
                : "bg-card border border-border text-muted-foreground hover:text-foreground hover:border-primary/30"
            )}>
            {t}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="grid gap-4 lg:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-52 rounded-2xl" />)}
        </div>
      ) : (projects ?? []).length === 0 ? (
        <EmptyState icon={FolderKanban} title="No projects found" description="Create your first interior project"
          action={<Button onClick={openCreate}><Plus className="mr-2 h-4 w-4" />New Project</Button>} />
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {(projects ?? []).map((p) => (
            <div key={p.id} className="rounded-2xl border border-border bg-card shadow-sm hover:shadow-lg transition-all duration-200 group overflow-hidden">
              <div className={cn("h-1.5", p.status === "completed" ? "bg-gradient-to-r from-emerald-500 to-teal-500" : p.status === "ongoing" ? "bg-gradient-to-r from-blue-500 to-cyan-500" : "bg-gradient-to-r from-amber-500 to-orange-500")} />
              <div className="p-5">
                <div className="flex items-start justify-between gap-2 mb-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <h3 className="font-bold text-foreground">{p.name}</h3>
                      <StatusBadge status={p.status} />
                    </div>
                    <p className="text-sm text-muted-foreground">{p.clientName}</p>
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => openEdit(p)} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>
                    <button onClick={() => setDeleteId(p.id)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-muted-foreground hover:text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground bg-muted/40 rounded-lg px-2.5 py-1.5">
                    <MapPin className="h-3.5 w-3.5 shrink-0 text-emerald-500" />
                    <span className="truncate">{p.location || "—"}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground bg-muted/40 rounded-lg px-2.5 py-1.5">
                    <IndianRupee className="h-3.5 w-3.5 shrink-0 text-violet-500" />
                    <span className="font-semibold text-foreground truncate">{formatCurrency(p.budget)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground bg-muted/40 rounded-lg px-2.5 py-1.5">
                    <Calendar className="h-3.5 w-3.5 shrink-0 text-sky-500" />
                    <span className="truncate">{formatDate(p.startDate)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground bg-muted/40 rounded-lg px-2.5 py-1.5">
                    <Calendar className="h-3.5 w-3.5 shrink-0 text-pink-500" />
                    <span className="truncate">{formatDate(p.endDate)}</span>
                  </div>
                </div>

                {p.assignedEmployees.length > 0 && (
                  <div className="mt-3 flex items-center gap-2 pt-3 border-t border-border">
                    <Users className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                    <div className="flex gap-1 flex-wrap">
                      {p.assignedEmployees.slice(0, 3).map((name) => (
                        <span key={name} className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full font-medium">{name}</span>
                      ))}
                      {p.assignedEmployees.length > 3 && (
                        <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">+{p.assignedEmployees.length - 3}</span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={dialog.open} onOpenChange={(open) => setDialog({ open, editing: null })}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className="h-6 w-1 rounded-full bg-gradient-to-b from-emerald-500 to-teal-600" />
              {dialog.editing ? "Edit Project" : "New Project"}
            </DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5 col-span-2"><Label>Project Name</Label><Input value={form.name} onChange={setField("name")} placeholder="Project title" /></div>
            <div className="space-y-1.5 col-span-2 sm:col-span-1">
              <Label>Client</Label>
              <Select value={form.clientId} onValueChange={setSelect("clientId")}>
                <SelectTrigger><SelectValue placeholder="Select client" /></SelectTrigger>
                <SelectContent>{(clients ?? []).map((c) => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5 col-span-2 sm:col-span-1">
              <Label>Status</Label>
              <Select value={form.status} onValueChange={setSelect("status")}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="ongoing">Ongoing</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Start Date</Label><Input type="date" value={form.startDate} onChange={setField("startDate")} /></div>
            <div className="space-y-1.5"><Label>End Date</Label><Input type="date" value={form.endDate} onChange={setField("endDate")} /></div>
            <div className="space-y-1.5"><Label>Budget (INR)</Label><Input type="number" value={form.budget} onChange={setField("budget")} placeholder="0" /></div>
            <div className="space-y-1.5"><Label>Location</Label><Input value={form.location} onChange={setField("location")} placeholder="Site address" /></div>
            <div className="space-y-1.5 col-span-2"><Label>Assigned Employees (comma-separated)</Label><Input value={form.assignedEmployees} onChange={setField("assignedEmployees")} placeholder="Name 1, Name 2" /></div>
            <div className="space-y-1.5 col-span-2"><Label>Notes</Label><Textarea value={form.notes} onChange={setField("notes")} rows={3} placeholder="Additional notes…" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialog({ open: false, editing: null })}>Cancel</Button>
            <Button onClick={handleSave} disabled={createMut.isPending || updateMut.isPending}
              className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white border-0">
              {dialog.editing ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={deleteId !== null} onOpenChange={() => setDeleteId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Delete Project</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">This will permanently delete this project.</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteId(null)}>Cancel</Button>
            <Button variant="destructive" onClick={() => { if (deleteId) deleteMut.mutate({ id: deleteId }, { onSuccess: () => { invalidate(); setDeleteId(null); } }); }} disabled={deleteMut.isPending}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
