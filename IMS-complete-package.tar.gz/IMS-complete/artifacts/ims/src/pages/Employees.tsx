import { useState } from "react";
import { useListEmployees, useCreateEmployee, useUpdateEmployee, useDeleteEmployee, getListEmployeesQueryKey } from "@workspace/api-client-react";
import type { Employee } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StatusBadge } from "@/components/StatusBadge";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency, formatDate } from "@/lib/utils";
import { UserRound, Plus, Pencil, Trash2, Phone, Mail, IndianRupee, Calendar } from "lucide-react";

type FormData = { name: string; email: string; phone: string; role: string; department: string; salary: string; joinDate: string; status: string };
const empty: FormData = { name: "", email: "", phone: "", role: "", department: "", salary: "", joinDate: "", status: "active" };

const DEPT_CONFIG: Record<string, { gradient: string; bg: string; text: string }> = {
  Design: { gradient: "from-violet-500 to-indigo-600", bg: "bg-violet-100 dark:bg-violet-950/50", text: "text-violet-700 dark:text-violet-300" },
  Operations: { gradient: "from-sky-500 to-cyan-600", bg: "bg-sky-100 dark:bg-sky-950/50", text: "text-sky-700 dark:text-sky-300" },
  Execution: { gradient: "from-amber-500 to-orange-500", bg: "bg-amber-100 dark:bg-amber-950/50", text: "text-amber-700 dark:text-amber-300" },
  Finance: { gradient: "from-emerald-500 to-teal-600", bg: "bg-emerald-100 dark:bg-emerald-950/50", text: "text-emerald-700 dark:text-emerald-300" },
  Sales: { gradient: "from-pink-500 to-rose-500", bg: "bg-pink-100 dark:bg-pink-950/50", text: "text-pink-700 dark:text-pink-300" },
  HR: { gradient: "from-blue-500 to-indigo-600", bg: "bg-blue-100 dark:bg-blue-950/50", text: "text-blue-700 dark:text-blue-300" },
};

export default function Employees() {
  const qc = useQueryClient();
  const { data: employees, isLoading } = useListEmployees();
  const createMut = useCreateEmployee();
  const updateMut = useUpdateEmployee();
  const deleteMut = useDeleteEmployee();
  const [dialog, setDialog] = useState<{ open: boolean; editing: Employee | null }>({ open: false, editing: null });
  const [form, setForm] = useState<FormData>(empty);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const invalidate = () => qc.invalidateQueries({ queryKey: getListEmployeesQueryKey() });
  const openCreate = () => { setForm(empty); setDialog({ open: true, editing: null }); };
  const openEdit = (e: Employee) => {
    setForm({ name: e.name, email: e.email, phone: e.phone, role: e.role, department: e.department, salary: String(e.salary), joinDate: e.joinDate, status: e.status });
    setDialog({ open: true, editing: e });
  };

  const handleSave = () => {
    const payload = { ...form, salary: parseFloat(form.salary) || 0, status: form.status as "active" | "inactive" };
    if (dialog.editing) {
      updateMut.mutate({ id: dialog.editing.id, data: payload }, { onSuccess: () => { invalidate(); setDialog({ open: false, editing: null }); } });
    } else {
      createMut.mutate({ data: payload }, { onSuccess: () => { invalidate(); setDialog({ open: false, editing: null }); } });
    }
  };

  const setField = (k: keyof FormData) => (e: React.ChangeEvent<HTMLInputElement>) => setForm((p) => ({ ...p, [k]: e.target.value }));
  const setSelect = (k: keyof FormData) => (v: string) => setForm((p) => ({ ...p, [k]: v }));

  const active = employees?.filter((e) => e.status === "active").length ?? 0;
  const total = employees?.length ?? 0;

  return (
    <div>
      <PageHeader
        title="Employees"
        subtitle="Manage your team members"
        icon={UserRound}
        gradient="bg-gradient-to-br from-pink-500 via-rose-500 to-orange-500"
        stats={[
          { label: "Total Staff", value: total },
          { label: "Active", value: active },
          { label: "Inactive", value: total - active },
        ]}
        action={
          <Button onClick={openCreate} className="bg-white/20 hover:bg-white/30 text-white border-0 backdrop-blur-sm shadow-none">
            <Plus className="mr-2 h-4 w-4" /> Add Employee
          </Button>
        }
      />

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-52 rounded-2xl" />)}
        </div>
      ) : (employees ?? []).length === 0 ? (
        <EmptyState icon={UserRound} title="No employees yet" description="Add your first team member"
          action={<Button onClick={openCreate}><Plus className="mr-2 h-4 w-4" />Add Employee</Button>} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {(employees ?? []).map((e) => {
            const dept = DEPT_CONFIG[e.department] ?? { gradient: "from-gray-400 to-gray-500", bg: "bg-gray-100 dark:bg-gray-800", text: "text-gray-600 dark:text-gray-400" };
            const initials = e.name.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase();
            return (
              <div key={e.id} className="rounded-2xl border border-border bg-card shadow-sm hover:shadow-lg transition-all duration-200 group overflow-hidden">
                <div className={`h-1.5 bg-gradient-to-r ${dept.gradient}`} />
                <div className="p-5">
                  <div className="flex items-start justify-between gap-2 mb-4">
                    <div className="flex items-center gap-3">
                      <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br ${dept.gradient} text-white font-bold text-base shadow-md`}>
                        {initials}
                      </div>
                      <div>
                        <h3 className="font-bold text-foreground">{e.name}</h3>
                        <p className="text-xs text-muted-foreground">{e.role}</p>
                      </div>
                    </div>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => openEdit(e)} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>
                      <button onClick={() => setDeleteId(e.id)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-muted-foreground hover:text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>
                    </div>
                  </div>

                  <div className="space-y-2 text-sm mb-4">
                    <div className="flex items-center gap-2.5 text-muted-foreground"><Mail className="h-3.5 w-3.5 shrink-0 text-violet-500" /><span className="truncate">{e.email}</span></div>
                    <div className="flex items-center gap-2.5 text-muted-foreground"><Phone className="h-3.5 w-3.5 shrink-0 text-sky-500" /><span>{e.phone}</span></div>
                    <div className="flex items-center gap-2.5 text-muted-foreground"><IndianRupee className="h-3.5 w-3.5 shrink-0 text-emerald-500" /><span className="font-semibold text-foreground">{formatCurrency(e.salary)}<span className="font-normal text-muted-foreground">/mo</span></span></div>
                    <div className="flex items-center gap-2.5 text-muted-foreground"><Calendar className="h-3.5 w-3.5 shrink-0 text-amber-500" /><span>Joined {formatDate(e.joinDate)}</span></div>
                  </div>

                  <div className="flex items-center gap-2 pt-3 border-t border-border">
                    <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${dept.bg} ${dept.text}`}>{e.department}</span>
                    <StatusBadge status={e.status} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={dialog.open} onOpenChange={(open) => setDialog({ open, editing: null })}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className="h-6 w-1 rounded-full bg-gradient-to-b from-pink-500 to-rose-600" />
              {dialog.editing ? "Edit Employee" : "Add Employee"}
            </DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5 col-span-2"><Label>Full Name</Label><Input value={form.name} onChange={setField("name")} placeholder="Full name" /></div>
            <div className="space-y-1.5"><Label>Email</Label><Input type="email" value={form.email} onChange={setField("email")} placeholder="Email" /></div>
            <div className="space-y-1.5"><Label>Phone</Label><Input value={form.phone} onChange={setField("phone")} placeholder="Phone number" /></div>
            <div className="space-y-1.5"><Label>Role</Label><Input value={form.role} onChange={setField("role")} placeholder="Job role" /></div>
            <div className="space-y-1.5">
              <Label>Department</Label>
              <Select value={form.department} onValueChange={setSelect("department")}>
                <SelectTrigger><SelectValue placeholder="Select dept" /></SelectTrigger>
                <SelectContent>{["Design", "Operations", "Execution", "Finance", "Sales", "HR"].map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Salary (INR/month)</Label><Input type="number" value={form.salary} onChange={setField("salary")} placeholder="0" /></div>
            <div className="space-y-1.5"><Label>Join Date</Label><Input type="date" value={form.joinDate} onChange={setField("joinDate")} /></div>
            <div className="space-y-1.5">
              <Label>Status</Label>
              <Select value={form.status} onValueChange={setSelect("status")}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="active">Active</SelectItem><SelectItem value="inactive">Inactive</SelectItem></SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialog({ open: false, editing: null })}>Cancel</Button>
            <Button onClick={handleSave} disabled={createMut.isPending || updateMut.isPending}
              className="bg-gradient-to-r from-pink-500 to-rose-600 text-white border-0">
              {dialog.editing ? "Update" : "Add"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={deleteId !== null} onOpenChange={() => setDeleteId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Remove Employee</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">This will permanently remove this employee record.</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteId(null)}>Cancel</Button>
            <Button variant="destructive" onClick={() => { if (deleteId) deleteMut.mutate({ id: deleteId }, { onSuccess: () => { invalidate(); setDeleteId(null); } }); }} disabled={deleteMut.isPending}>Remove</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
