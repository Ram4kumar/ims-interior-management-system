import { useGetExpenseByCategory, useGetProjectCompletionReport, useGetPendingPayments, useGetMonthlyRevenue } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/PageHeader";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency } from "@/lib/utils";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { BarChart3, TrendingUp, AlertCircle, CheckCircle2, Clock } from "lucide-react";

const PIE_COLORS = ["#6366f1", "#f59e0b", "#10b981", "#ef4444", "#8b5cf6", "#06b6d4", "#f97316", "#ec4899"];

export default function Reports() {
  const { data: expCat, isLoading: catLoading } = useGetExpenseByCategory();
  const { data: completion, isLoading: compLoading } = useGetProjectCompletionReport();
  const { data: pending, isLoading: pendLoading } = useGetPendingPayments();
  const { data: revenue, isLoading: revLoading } = useGetMonthlyRevenue();

  const totalRevenue = (revenue ?? []).reduce((s, r) => s + r.revenue, 0);
  const totalExpenses = (revenue ?? []).reduce((s, r) => s + r.expenses, 0);

  return (
    <div>
      <PageHeader
        title="Reports"
        subtitle="Financial analytics & business insights"
        icon={BarChart3}
        gradient="bg-gradient-to-br from-purple-500 via-violet-500 to-indigo-600"
        stats={[
          { label: "Total Revenue", value: formatCurrency(totalRevenue) },
          { label: "Total Expenses", value: formatCurrency(totalExpenses) },
          { label: "Net Profit", value: formatCurrency(totalRevenue - totalExpenses) },
        ]}
      />

      {/* Summary cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-6">
        {pendLoading ? (
          Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-2xl" />)
        ) : (
          <>
            {[
              { label: "Pending Payments", value: formatCurrency(pending?.totalPending ?? 0), sub: `${pending?.invoiceCount} invoices`, icon: AlertCircle, gradient: "from-amber-500 to-orange-500", glow: "shadow-amber-500/20" },
              { label: "Overdue Amount", value: formatCurrency(pending?.totalOverdue ?? 0), sub: `${pending?.overdueCount} overdue`, icon: Clock, gradient: "from-red-500 to-rose-600", glow: "shadow-red-500/20" },
              { label: "Projects Done", value: `${completion?.completed ?? 0} / ${completion?.total ?? 0}`, sub: `${completion?.completionRate ?? 0}% rate`, icon: CheckCircle2, gradient: "from-emerald-500 to-teal-600", glow: "shadow-emerald-500/20" },
              { label: "Ongoing Projects", value: completion?.ongoing ?? 0, sub: `${completion?.pending ?? 0} pending`, icon: TrendingUp, gradient: "from-blue-500 to-indigo-600", glow: "shadow-blue-500/20" },
            ].map(({ label, value, sub, icon: Icon, gradient, glow }) => (
              <div key={label} className={`relative overflow-hidden rounded-2xl p-5 text-white shadow-lg ${glow} bg-gradient-to-br ${gradient}`}>
                <div className="absolute -right-4 -top-4 h-20 w-20 rounded-full bg-white/10" />
                <div className="relative">
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-xs font-semibold uppercase tracking-wider text-white/70">{label}</p>
                    <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/20"><Icon className="h-4 w-4 text-white" /></div>
                  </div>
                  <p className="text-xl font-black text-white">{value}</p>
                  <p className="text-xs text-white/65 mt-0.5">{sub}</p>
                </div>
              </div>
            ))}
          </>
        )}
      </div>

      <div className="grid gap-5 lg:grid-cols-2 mb-5">
        {/* Expense by Category */}
        <Card className="overflow-hidden">
          <CardHeader className="pb-2 border-b border-border">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-gradient-to-r from-violet-500 to-indigo-500" />
              Expenses by Category
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            {catLoading ? <Skeleton className="h-64 w-full" /> : (
              <div className="flex flex-col items-center gap-5">
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie data={expCat ?? []} dataKey="total" nameKey="category" cx="50%" cy="50%" outerRadius={82} innerRadius={44} strokeWidth={3} stroke="hsl(var(--card))">
                      {(expCat ?? []).map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                    </Pie>
                    <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 10, fontSize: 12 }} formatter={(v: number) => [formatCurrency(v), ""]} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="grid grid-cols-2 gap-x-6 gap-y-2 w-full">
                  {(expCat ?? []).map((item, i) => (
                    <div key={item.category} className="flex items-center justify-between gap-2 text-sm">
                      <div className="flex items-center gap-2">
                        <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ backgroundColor: PIE_COLORS[i % PIE_COLORS.length] }} />
                        <span className="text-muted-foreground truncate text-xs">{item.category}</span>
                      </div>
                      <span className="font-bold text-xs text-foreground whitespace-nowrap">{formatCurrency(item.total)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Project Completion */}
        <Card className="overflow-hidden">
          <CardHeader className="pb-2 border-b border-border">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-gradient-to-r from-emerald-500 to-teal-500" />
              Project Completion Rate
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            {compLoading ? <Skeleton className="h-64 w-full" /> : (
              <div className="space-y-5">
                <div className="text-center py-4 relative">
                  <div className="inline-flex h-28 w-28 items-center justify-center rounded-full border-8 border-emerald-500/20">
                    <div className="text-center">
                      <p className="text-3xl font-black text-emerald-600 dark:text-emerald-400">{completion?.completionRate ?? 0}%</p>
                      <p className="text-xs text-muted-foreground">done</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  {[
                    { label: "Completed", value: completion?.completed ?? 0, total: completion?.total ?? 1, gradient: "from-emerald-500 to-teal-500" },
                    { label: "Ongoing", value: completion?.ongoing ?? 0, total: completion?.total ?? 1, gradient: "from-blue-500 to-cyan-500" },
                    { label: "Pending", value: completion?.pending ?? 0, total: completion?.total ?? 1, gradient: "from-amber-500 to-orange-500" },
                  ].map(({ label, value, total, gradient }) => (
                    <div key={label}>
                      <div className="flex justify-between text-sm mb-1.5">
                        <span className="font-medium text-foreground">{label}</span>
                        <span className="text-muted-foreground">{value} of {total}</span>
                      </div>
                      <div className="h-2.5 rounded-full bg-muted overflow-hidden">
                        <div className={`h-full rounded-full bg-gradient-to-r ${gradient} transition-all duration-700`}
                          style={{ width: `${total > 0 ? (value / total) * 100 : 0}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Revenue vs Expenses Bar Chart */}
      <Card className="overflow-hidden">
        <CardHeader className="pb-2 border-b border-border flex flex-row items-center justify-between">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full bg-gradient-to-r from-violet-500 to-indigo-500" />
            Monthly Revenue vs Expenses
          </CardTitle>
          <div className="flex gap-4 text-xs">
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-violet-500" />Revenue</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-amber-500" />Expenses</span>
          </div>
        </CardHeader>
        <CardContent className="pt-4">
          {revLoading ? <Skeleton className="h-56 w-full" /> : (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={revenue ?? []} barGap={6} barCategoryGap="30%">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12, fontSize: 12, boxShadow: "0 10px 40px rgba(0,0,0,.15)" }} formatter={(v: number) => [formatCurrency(v), ""]} />
                <Bar dataKey="revenue" radius={[6, 6, 0, 0]} name="Revenue">
                  {(revenue ?? []).map((_, i) => <Cell key={i} fill={`url(#revBar${i})`} />)}
                </Bar>
                <Bar dataKey="expenses" radius={[6, 6, 0, 0]} name="Expenses">
                  {(revenue ?? []).map((_, i) => <Cell key={i} fill={`url(#expBar${i})`} />)}
                </Bar>
                <defs>
                  {(revenue ?? []).map((_, i) => (
                    <linearGradient key={i} id={`revBar${i}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#7c3aed" /><stop offset="100%" stopColor="#4f46e5" />
                    </linearGradient>
                  ))}
                  {(revenue ?? []).map((_, i) => (
                    <linearGradient key={i} id={`expBar${i}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#f59e0b" /><stop offset="100%" stopColor="#f97316" />
                    </linearGradient>
                  ))}
                </defs>
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
