import { useState } from "react";
import { useListExpenses, useCreateExpense, useUpdateExpense, useDeleteExpense, useListProjects, getListExpensesQueryKey } from "@workspace/api-client-react";
import type { Expense } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency, formatDate } from "@/lib/utils";
import { Receipt, Plus, Pencil, Trash2 } from "lucide-react";

const CATEGORIES = ["Materials", "Labour", "Transport", "Equipment", "Office", "Technology", "Marketing", "Miscellaneous"];

type FormData = { title: string; amount: string; category: string; projectId: string; date: string; description: string };
const empty: FormData = { title: "", amount: "", category: "Materials", projectId: "", date: "", description: "" };

const CAT_STYLES: Record<string, { bg: string; text: string; dot: string }> = {
  Materials: { bg: "bg-blue-100 dark:bg-blue-950/50", text: "text-blue-700 dark:text-blue-300", dot: "bg-blue-500" },
  Labour: { bg: "bg-violet-100 dark:bg-violet-950/50", text: "text-violet-700 dark:text-violet-300", dot: "bg-violet-500" },
  Transport: { bg: "bg-amber-100 dark:bg-amber-950/50", text: "text-amber-700 dark:text-amber-300", dot: "bg-amber-500" },
  Equipment: { bg: "bg-teal-100 dark:bg-teal-950/50", text: "text-teal-700 dark:text-teal-300", dot: "bg-teal-500" },
  Office: { bg: "bg-gray-100 dark:bg-gray-800", text: "text-gray-700 dark:text-gray-300", dot: "bg-gray-500" },
  Technology: { bg: "bg-indigo-100 dark:bg-indigo-950/50", text: "text-indigo-700 dark:text-indigo-300", dot: "bg-indigo-500" },
  Marketing: { bg: "bg-pink-100 dark:bg-pink-950/50", text: "text-pink-700 dark:text-pink-300", dot: "bg-pink-500" },
  Miscellaneous: { bg: "bg-orange-100 dark:bg-orange-950/50", text: "text-orange-700 dark:text-orange-300", dot: "bg-orange-500" },
};

export default function Expenses() {
  const qc = useQueryClient();
  const [filterCat, setFilterCat] = useState("");
  const { data: expenses, isLoading } = useListExpenses({ category: filterCat || undefined });
  const { data: projects } = useListProjects();
  const createMut = useCreateExpense();
  const updateMut = useUpdateExpense();
  const deleteMut = useDeleteExpense();
  const [dialog, setDialog] = useState<{ open: boolean; editing: Expense | null }>({ open: false, editing: null });
  const [form, setForm] = useState<FormData>(empty);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const invalidate = () => qc.invalidateQueries({ queryKey: getListExpensesQueryKey() });
  const total = (expenses ?? []).reduce((s, e) => s + e.amount, 0);

  const openCreate = () => { setForm(empty); setDialog({ open: true, editing: null }); };
  const openEdit = (e: Expense) => {
    setForm({ title: e.title, amount: String(e.amount), category: e.category, projectId: e.projectId ? String(e.projectId) : "", date: e.date, description: e.description });
    setDialog({ open: true, editing: e });
  };

  const handleSave = () => {
    const payload = { title: form.title, amount: parseFloat(form.amount) || 0, category: form.category, projectId: form.projectId ? parseInt(form.projectId) : null, date: form.date, description: form.description };
    if (dialog.editing) {
      updateMut.mutate({ id: dialog.editing.id, data: payload }, { onSuccess: () => { invalidate(); setDialog({ open: false, editing: null }); } });
    } else {
      createMut.mutate({ data: payload }, { onSuccess: () => { invalidate(); setDialog({ open: false, editing: null }); } });
    }
  };

  const setField = (k: keyof FormData) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setForm((p) => ({ ...p, [k]: e.target.value }));
  const setSelect = (k: keyof FormData) => (v: string) => setForm((p) => ({ ...p, [k]: v }));

  return (
    <div>
      <PageHeader
        title="Expenses"
        subtitle="Track all project & operational costs"
        icon={Receipt}
        gradient="bg-gradient-to-br from-red-500 via-rose-500 to-pink-600"
        stats={[
          { label: "Total Entries", value: expenses?.length ?? 0 },
          { label: "Total Amount", value: formatCurrency(total) },
          { label: "Categories", value: new Set(expenses?.map((e) => e.category)).size },
        ]}
        action={
          <Button onClick={openCreate} className="bg-white/20 hover:bg-white/30 text-white border-0 backdrop-blur-sm shadow-none">
            <Plus className="mr-2 h-4 w-4" /> Add Expense
          </Button>
        }
      />

      {/* Filter */}
      <div className="flex items-center gap-3 mb-5 flex-wrap">
        <Select value={filterCat || "_all"} onValueChange={(v) => setFilterCat(v === "_all" ? "" : v)}>
          <SelectTrigger className="w-48 rounded-xl"><SelectValue placeholder="All categories" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="_all">All categories</SelectItem>
            {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        {total > 0 && (
          <div className="flex items-center gap-2 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-xl px-3.5 py-2">
            <span className="text-xs text-red-600 dark:text-red-400 font-medium">Total</span>
            <span className="text-sm font-bold text-red-700 dark:text-red-300">{formatCurrency(total)}</span>
          </div>
        )}
      </div>

      {isLoading ? (
        <div className="space-y-2">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-14 rounded-xl" />)}</div>
      ) : (expenses ?? []).length === 0 ? (
        <EmptyState icon={Receipt} title="No expenses found" description="Record your first expense"
          action={<Button onClick={openCreate}><Plus className="mr-2 h-4 w-4" />Add Expense</Button>} />
      ) : (
        <div className="rounded-2xl border border-border bg-card shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/50">
                  <th className="text-left px-5 py-3.5 font-semibold text-muted-foreground">Title</th>
                  <th className="text-left px-5 py-3.5 font-semibold text-muted-foreground">Category</th>
                  <th className="text-left px-5 py-3.5 font-semibold text-muted-foreground">Project</th>
                  <th className="text-left px-5 py-3.5 font-semibold text-muted-foreground">Date</th>
                  <th className="text-right px-5 py-3.5 font-semibold text-muted-foreground">Amount</th>
                  <th className="px-4 py-3.5"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {(expenses ?? []).map((e) => {
                  const cat = CAT_STYLES[e.category] ?? { bg: "bg-gray-100 dark:bg-gray-800", text: "text-gray-700 dark:text-gray-300", dot: "bg-gray-400" };
                  return (
                    <tr key={e.id} className="hover:bg-muted/30 transition-colors group">
                      <td className="px-5 py-3.5 font-semibold text-foreground">{e.title}</td>
                      <td className="px-5 py-3.5">
                        <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${cat.bg} ${cat.text}`}>
                          <span className={`h-1.5 w-1.5 rounded-full ${cat.dot}`} />{e.category}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-muted-foreground">{e.projectName ?? "—"}</td>
                      <td className="px-5 py-3.5 text-muted-foreground whitespace-nowrap">{formatDate(e.date)}</td>
                      <td className="px-5 py-3.5 text-right font-bold text-foreground">{formatCurrency(e.amount)}</td>
                      <td className="px-4 py-3.5">
                        <div className="flex gap-1 justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                          <button onClick={() => openEdit(e)} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>
                          <button onClick={() => setDeleteId(e.id)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-muted-foreground hover:text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-border bg-muted/30">
                  <td colSpan={4} className="px-5 py-3 text-sm font-semibold text-muted-foreground">{(expenses ?? []).length} entries</td>
                  <td className="px-5 py-3 text-right text-base font-black text-foreground">{formatCurrency(total)}</td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      <Dialog open={dialog.open} onOpenChange={(open) => setDialog({ open, editing: null })}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className="h-6 w-1 rounded-full bg-gradient-to-b from-red-500 to-rose-600" />
              {dialog.editing ? "Edit Expense" : "Add Expense"}
            </DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5 col-span-2"><Label>Title</Label><Input value={form.title} onChange={setField("title")} placeholder="Expense title" /></div>
            <div className="space-y-1.5"><Label>Amount (INR)</Label><Input type="number" value={form.amount} onChange={setField("amount")} placeholder="0" /></div>
            <div className="space-y-1.5">
              <Label>Category</Label>
              <Select value={form.category} onValueChange={setSelect("category")}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Project (optional)</Label>
              <Select value={form.projectId || "_none"} onValueChange={(v) => setSelect("projectId")(v === "_none" ? "" : v)}>
                <SelectTrigger><SelectValue placeholder="No project" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="_none">No project</SelectItem>
                  {(projects ?? []).map((p) => <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Date</Label><Input type="date" value={form.date} onChange={setField("date")} /></div>
            <div className="space-y-1.5 col-span-2"><Label>Description</Label><Textarea value={form.description} onChange={setField("description")} rows={2} placeholder="Details…" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialog({ open: false, editing: null })}>Cancel</Button>
            <Button onClick={handleSave} disabled={createMut.isPending || updateMut.isPending}
              className="bg-gradient-to-r from-red-500 to-rose-600 text-white border-0">
              {dialog.editing ? "Update" : "Add"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={deleteId !== null} onOpenChange={() => setDeleteId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Delete Expense</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">This will permanently delete this expense record.</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteId(null)}>Cancel</Button>
            <Button variant="destructive" onClick={() => { if (deleteId) deleteMut.mutate({ id: deleteId }, { onSuccess: () => { invalidate(); setDeleteId(null); } }); }} disabled={deleteMut.isPending}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
