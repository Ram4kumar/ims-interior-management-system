import { cn } from "@/lib/utils";

const STATUS_STYLES: Record<string, string> = {
  pending: "bg-amber-100 text-amber-800 ring-1 ring-amber-300 dark:bg-amber-500/20 dark:text-amber-300 dark:ring-amber-500/40",
  ongoing: "bg-blue-100 text-blue-800 ring-1 ring-blue-300 dark:bg-blue-500/20 dark:text-blue-300 dark:ring-blue-500/40",
  completed: "bg-emerald-100 text-emerald-800 ring-1 ring-emerald-300 dark:bg-emerald-500/20 dark:text-emerald-300 dark:ring-emerald-500/40",
  paid: "bg-emerald-100 text-emerald-800 ring-1 ring-emerald-300 dark:bg-emerald-500/20 dark:text-emerald-300 dark:ring-emerald-500/40",
  overdue: "bg-red-100 text-red-800 ring-1 ring-red-300 dark:bg-red-500/20 dark:text-red-300 dark:ring-red-500/40",
  cancelled: "bg-gray-100 text-gray-600 ring-1 ring-gray-300 dark:bg-gray-500/20 dark:text-gray-400 dark:ring-gray-500/40",
  active: "bg-emerald-100 text-emerald-800 ring-1 ring-emerald-300 dark:bg-emerald-500/20 dark:text-emerald-300 dark:ring-emerald-500/40",
  inactive: "bg-gray-100 text-gray-600 ring-1 ring-gray-300 dark:bg-gray-500/20 dark:text-gray-400 dark:ring-gray-500/40",
};

const STATUS_DOT: Record<string, string> = {
  pending: "bg-amber-500",
  ongoing: "bg-blue-500",
  completed: "bg-emerald-500",
  paid: "bg-emerald-500",
  overdue: "bg-red-500",
  cancelled: "bg-gray-400",
  active: "bg-emerald-500",
  inactive: "bg-gray-400",
};

export function StatusBadge({ status }: { status: string }) {
  const style = STATUS_STYLES[status] ?? "bg-gray-100 text-gray-600 ring-1 ring-gray-300";
  const dot = STATUS_DOT[status] ?? "bg-gray-400";
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-semibold capitalize", style)}>
      <span className={cn("h-1.5 w-1.5 rounded-full", dot)} />
      {status}
    </span>
  );
}
