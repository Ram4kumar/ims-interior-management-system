import type { LucideIcon } from "lucide-react";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  icon: LucideIcon;
  gradient: string;
  action?: React.ReactNode;
  stats?: { label: string; value: string | number }[];
}

export function PageHeader({ title, subtitle, icon: Icon, gradient, action, stats }: PageHeaderProps) {
  return (
    <div className={`relative overflow-hidden rounded-2xl p-6 mb-5 text-white shadow-lg ${gradient}`}>
      {/* Background decoration */}
      <div className="absolute -right-8 -top-8 h-36 w-36 rounded-full bg-white/10" />
      <div className="absolute right-16 -bottom-6 h-24 w-24 rounded-full bg-white/8" />
      <div className="absolute -right-2 top-16 h-10 w-10 rounded-full bg-white/12" />

      <div className="relative flex items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white/20 shadow-inner">
            <Icon className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white">{title}</h2>
            {subtitle && <p className="text-sm text-white/65 mt-0.5">{subtitle}</p>}
          </div>
        </div>
        {action && <div>{action}</div>}
      </div>

      {stats && stats.length > 0 && (
        <div className="relative mt-5 pt-4 border-t border-white/15 grid grid-cols-3 gap-4">
          {stats.map((s) => (
            <div key={s.label}>
              <p className="text-lg font-black text-white">{s.value}</p>
              <p className="text-xs text-white/60 mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
