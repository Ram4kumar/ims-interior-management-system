import { Router } from "express";
import { db } from "@workspace/db";
import { clientsTable, activitiesTable } from "@workspace/db";
import { eq, ilike, or } from "drizzle-orm";
import {
  CreateClientBody,
  UpdateClientBody,
} from "@workspace/api-zod";

const router = Router();

function toClientJson(c: typeof clientsTable.$inferSelect) {
  return {
    id: c.id,
    name: c.name,
    phone: c.phone,
    email: c.email,
    address: c.address,
    requirements: c.requirements,
    budget: parseFloat(c.budget as string),
    createdAt: c.createdAt.toISOString(),
  };
}

router.get("/", async (req, res) => {
  try {
    const { search } = req.query as { search?: string };
    let rows;
    if (search) {
      rows = await db
        .select()
        .from(clientsTable)
        .where(
          or(
            ilike(clientsTable.name, `%${search}%`),
            ilike(clientsTable.email, `%${search}%`),
            ilike(clientsTable.phone, `%${search}%`)
          )
        )
        .orderBy(clientsTable.createdAt);
    } else {
      rows = await db.select().from(clientsTable).orderBy(clientsTable.createdAt);
    }
    res.json(rows.map(toClientJson));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch clients" });
  }
});

router.post("/", async (req, res) => {
  try {
    const parsed = CreateClientBody.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }
    const data = parsed.data;
    const [client] = await db
      .insert(clientsTable)
      .values({
        name: data.name,
        phone: data.phone,
        email: data.email,
        address: data.address,
        requirements: data.requirements,
        budget: String(data.budget),
      })
      .returning();
    await db.insert(activitiesTable).values({
      type: "client_added",
      description: `New client added: ${client.name}`,
    });
    res.status(201).json(toClientJson(client));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create client" });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [client] = await db.select().from(clientsTable).where(eq(clientsTable.id, id));
    if (!client) return res.status(404).json({ error: "Client not found" });
    res.json(toClientJson(client));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch client" });
  }
});

router.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const parsed = UpdateClientBody.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }
    const data = parsed.data;
    const updateData: Partial<typeof clientsTable.$inferInsert> = {};
    if (data.name !== undefined) updateData.name = data.name;
    if (data.phone !== undefined) updateData.phone = data.phone;
    if (data.email !== undefined) updateData.email = data.email;
    if (data.address !== undefined) updateData.address = data.address;
    if (data.requirements !== undefined) updateData.requirements = data.requirements;
    if (data.budget !== undefined) updateData.budget = String(data.budget);

    const [updated] = await db
      .update(clientsTable)
      .set(updateData)
      .where(eq(clientsTable.id, id))
      .returning();
    if (!updated) return res.status(404).json({ error: "Client not found" });
    res.json(toClientJson(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update client" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [deleted] = await db
      .delete(clientsTable)
      .where(eq(clientsTable.id, id))
      .returning();
    if (!deleted) return res.status(404).json({ error: "Client not found" });
    await db.insert(activitiesTable).values({
      type: "client_deleted",
      description: `Client removed: ${deleted.name}`,
    });
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete client" });
  }
});

export default router;
