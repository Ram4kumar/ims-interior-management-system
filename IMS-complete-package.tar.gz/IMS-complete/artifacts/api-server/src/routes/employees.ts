import { Router } from "express";
import { db } from "@workspace/db";
import { employeesTable, activitiesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CreateEmployeeBody,
  UpdateEmployeeBody,
} from "@workspace/api-zod";

const router = Router();

function toEmployeeJson(e: typeof employeesTable.$inferSelect) {
  return {
    id: e.id,
    name: e.name,
    email: e.email,
    phone: e.phone,
    role: e.role,
    department: e.department,
    salary: parseFloat(e.salary as string),
    joinDate: e.joinDate,
    status: e.status,
    createdAt: e.createdAt.toISOString(),
  };
}

router.get("/", async (req, res) => {
  try {
    const rows = await db.select().from(employeesTable).orderBy(employeesTable.createdAt);
    res.json(rows.map(toEmployeeJson));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch employees" });
  }
});

router.post("/", async (req, res) => {
  try {
    const parsed = CreateEmployeeBody.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }
    const data = parsed.data;
    const [employee] = await db
      .insert(employeesTable)
      .values({
        name: data.name,
        email: data.email,
        phone: data.phone,
        role: data.role,
        department: data.department,
        salary: String(data.salary),
        joinDate: data.joinDate,
        status: data.status ?? "active",
      })
      .returning();
    await db.insert(activitiesTable).values({
      type: "employee_added",
      description: `New employee added: ${employee.name} (${employee.role})`,
    });
    res.status(201).json(toEmployeeJson(employee));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create employee" });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [employee] = await db.select().from(employeesTable).where(eq(employeesTable.id, id));
    if (!employee) return res.status(404).json({ error: "Employee not found" });
    res.json(toEmployeeJson(employee));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch employee" });
  }
});

router.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const parsed = UpdateEmployeeBody.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }
    const data = parsed.data;
    const updateData: Record<string, unknown> = {};
    if (data.name !== undefined) updateData.name = data.name;
    if (data.email !== undefined) updateData.email = data.email;
    if (data.phone !== undefined) updateData.phone = data.phone;
    if (data.role !== undefined) updateData.role = data.role;
    if (data.department !== undefined) updateData.department = data.department;
    if (data.salary !== undefined) updateData.salary = String(data.salary);
    if (data.joinDate !== undefined) updateData.joinDate = data.joinDate;
    if (data.status !== undefined) updateData.status = data.status;

    const [updated] = await db
      .update(employeesTable)
      .set(updateData)
      .where(eq(employeesTable.id, id))
      .returning();
    if (!updated) return res.status(404).json({ error: "Employee not found" });
    res.json(toEmployeeJson(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update employee" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [deleted] = await db
      .delete(employeesTable)
      .where(eq(employeesTable.id, id))
      .returning();
    if (!deleted) return res.status(404).json({ error: "Employee not found" });
    await db.insert(activitiesTable).values({
      type: "employee_removed",
      description: `Employee removed: ${deleted.name}`,
    });
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete employee" });
  }
});

export default router;
