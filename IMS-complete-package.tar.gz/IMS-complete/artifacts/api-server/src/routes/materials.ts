import { Router } from "express";
import { db } from "@workspace/db";
import { materialsTable, activitiesTable } from "@workspace/db";
import { eq, lte, sql } from "drizzle-orm";
import {
  CreateMaterialBody,
  UpdateMaterialBody,
} from "@workspace/api-zod";

const router = Router();

function toMaterialJson(m: typeof materialsTable.$inferSelect) {
  return {
    id: m.id,
    name: m.name,
    quantity: m.quantity,
    unit: m.unit,
    unitPrice: parseFloat(m.unitPrice as string),
    supplierName: m.supplierName,
    lowStockThreshold: m.lowStockThreshold,
    isLowStock: m.quantity <= m.lowStockThreshold,
    createdAt: m.createdAt.toISOString(),
  };
}

router.get("/", async (req, res) => {
  try {
    const { lowStock } = req.query as { lowStock?: string };
    let rows = await db.select().from(materialsTable).orderBy(materialsTable.name);
    if (lowStock === "true") {
      rows = rows.filter((m) => m.quantity <= m.lowStockThreshold);
    }
    res.json(rows.map(toMaterialJson));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch materials" });
  }
});

router.post("/", async (req, res) => {
  try {
    const parsed = CreateMaterialBody.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }
    const data = parsed.data;
    const [material] = await db
      .insert(materialsTable)
      .values({
        name: data.name,
        quantity: data.quantity,
        unit: data.unit,
        unitPrice: String(data.unitPrice),
        supplierName: data.supplierName,
        lowStockThreshold: data.lowStockThreshold,
      })
      .returning();
    await db.insert(activitiesTable).values({
      type: "material_added",
      description: `Material added: ${material.name} (qty: ${material.quantity} ${material.unit})`,
    });
    res.status(201).json(toMaterialJson(material));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create material" });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [material] = await db.select().from(materialsTable).where(eq(materialsTable.id, id));
    if (!material) return res.status(404).json({ error: "Material not found" });
    res.json(toMaterialJson(material));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch material" });
  }
});

router.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const parsed = UpdateMaterialBody.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }
    const data = parsed.data;
    const updateData: Record<string, unknown> = {};
    if (data.name !== undefined) updateData.name = data.name;
    if (data.quantity !== undefined) updateData.quantity = data.quantity;
    if (data.unit !== undefined) updateData.unit = data.unit;
    if (data.unitPrice !== undefined) updateData.unitPrice = String(data.unitPrice);
    if (data.supplierName !== undefined) updateData.supplierName = data.supplierName;
    if (data.lowStockThreshold !== undefined) updateData.lowStockThreshold = data.lowStockThreshold;

    const [updated] = await db
      .update(materialsTable)
      .set(updateData)
      .where(eq(materialsTable.id, id))
      .returning();
    if (!updated) return res.status(404).json({ error: "Material not found" });
    res.json(toMaterialJson(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update material" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [deleted] = await db
      .delete(materialsTable)
      .where(eq(materialsTable.id, id))
      .returning();
    if (!deleted) return res.status(404).json({ error: "Material not found" });
    await db.insert(activitiesTable).values({
      type: "material_removed",
      description: `Material removed: ${deleted.name}`,
    });
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete material" });
  }
});

export default router;
