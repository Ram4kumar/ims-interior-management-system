-- =============================================================================
--  IMS — Interior Management System
--  Database Setup Script
-- =============================================================================
--  HOW TO USE:
--
--  Option 1 — Command line:
--    psql -U postgres -c "CREATE DATABASE ims;"
--    psql -U postgres -d ims -f ims_database.sql
--
--  Option 2 — pgAdmin (GUI):
--    1. Open pgAdmin → right-click Databases → Create → Database → name it "ims"
--    2. Click on the "ims" database → click "Query Tool"
--    3. Open this file (File → Open) → press F5 to run
--
--  Option 3 — DBeaver or TablePlus:
--    1. Create a new database called "ims"
--    2. Open SQL editor, paste or open this file, and run it
--
--  After running this script:
--    - All tables are created
--    - Sample data is loaded (6 clients, 7 employees, 6 projects, etc.)
--    - Start the IMS app and changes in the UI will update these tables
-- =============================================================================

-- Drop tables if re-running (safe clean slate)
DROP TABLE IF EXISTS activities   CASCADE;
DROP TABLE IF EXISTS invoices      CASCADE;
DROP TABLE IF EXISTS expenses      CASCADE;
DROP TABLE IF EXISTS materials     CASCADE;
DROP TABLE IF EXISTS employees     CASCADE;
DROP TABLE IF EXISTS projects      CASCADE;
DROP TABLE IF EXISTS clients       CASCADE;

-- =============================================================================
--  TABLE: clients
-- =============================================================================
CREATE TABLE clients (
    id          SERIAL PRIMARY KEY,
    name        TEXT NOT NULL,
    phone       TEXT NOT NULL,
    email       TEXT NOT NULL,
    address     TEXT NOT NULL,
    requirements TEXT NOT NULL DEFAULT '',
    budget      DECIMAL(12, 2) NOT NULL DEFAULT 0,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
--  TABLE: projects
-- =============================================================================
CREATE TABLE projects (
    id                  SERIAL PRIMARY KEY,
    name                TEXT NOT NULL,
    client_id           INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    status              TEXT NOT NULL DEFAULT 'pending',
    start_date          TEXT NOT NULL,
    end_date            TEXT NOT NULL,
    budget              DECIMAL(12, 2) NOT NULL DEFAULT 0,
    location            TEXT NOT NULL DEFAULT '',
    notes               TEXT NOT NULL DEFAULT '',
    assigned_employees  TEXT NOT NULL DEFAULT '[]',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
--  TABLE: employees
-- =============================================================================
CREATE TABLE employees (
    id          SERIAL PRIMARY KEY,
    name        TEXT NOT NULL,
    email       TEXT NOT NULL,
    phone       TEXT NOT NULL,
    role        TEXT NOT NULL,
    department  TEXT NOT NULL,
    salary      DECIMAL(12, 2) NOT NULL DEFAULT 0,
    join_date   TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'active',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
--  TABLE: materials
-- =============================================================================
CREATE TABLE materials (
    id                  SERIAL PRIMARY KEY,
    name                TEXT NOT NULL,
    quantity            INTEGER NOT NULL DEFAULT 0,
    unit                TEXT NOT NULL DEFAULT 'pcs',
    unit_price          DECIMAL(12, 2) NOT NULL DEFAULT 0,
    supplier_name       TEXT NOT NULL DEFAULT '',
    low_stock_threshold INTEGER NOT NULL DEFAULT 10,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
--  TABLE: expenses
-- =============================================================================
CREATE TABLE expenses (
    id          SERIAL PRIMARY KEY,
    title       TEXT NOT NULL,
    amount      DECIMAL(12, 2) NOT NULL DEFAULT 0,
    category    TEXT NOT NULL,
    project_id  INTEGER REFERENCES projects(id) ON DELETE SET NULL,
    date        TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
--  TABLE: invoices
-- =============================================================================
CREATE TABLE invoices (
    id              SERIAL PRIMARY KEY,
    invoice_number  TEXT NOT NULL UNIQUE,
    client_id       INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    project_id      INTEGER REFERENCES projects(id) ON DELETE SET NULL,
    amount          DECIMAL(12, 2) NOT NULL DEFAULT 0,
    tax_rate        DECIMAL(5, 2) NOT NULL DEFAULT 18,
    status          TEXT NOT NULL DEFAULT 'pending',
    due_date        TEXT NOT NULL,
    issue_date      TEXT NOT NULL,
    notes           TEXT NOT NULL DEFAULT '',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
--  TABLE: activities
-- =============================================================================
CREATE TABLE activities (
    id          SERIAL PRIMARY KEY,
    type        TEXT NOT NULL,
    description TEXT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
--  SAMPLE DATA — Clients
-- =============================================================================
INSERT INTO clients (name, phone, email, address, requirements, budget) VALUES
('Priya Sharma',   '9876543210', 'priya.sharma@email.com',  '14, MG Road, Bengaluru 560001',         'Modern minimalist 3BHK renovation',            1500000),
('Rahul Mehta',    '9812345678', 'rahul.mehta@email.com',   '7, Bandra West, Mumbai 400050',          'Scandinavian style living room & kitchen',     800000),
('Ananya Iyer',    '9765432109', 'ananya.iyer@email.com',   '22, Anna Nagar, Chennai 600040',         'Full villa interior from scratch',              3500000),
('Vikram Patel',   '9723456789', 'vikram.patel@email.com',  '9, C-Scheme, Jaipur 302001',             'Office interior design — 3000 sq ft',           2000000),
('Meera Nair',     '9698765432', 'meera.nair@email.com',    '45, Jubilee Hills, Hyderabad 500033',    'Luxury master bedroom & bathrooms',            600000),
('Arjun Kapoor',   '9654321098', 'arjun.kapoor@email.com',  '3, South Extension, New Delhi 110049',  'Contemporary 4BHK with home office',           2500000);

-- =============================================================================
--  SAMPLE DATA — Employees
-- =============================================================================
INSERT INTO employees (name, email, phone, role, department, salary, join_date, status) VALUES
('Sneha Reddy',   'sneha.reddy@ims.com',   '9811223344', 'Lead Designer',      'Design',     85000, '2021-03-15', 'active'),
('Karan Bose',    'karan.bose@ims.com',    '9822334455', 'Project Manager',    'Operations', 75000, '2020-07-01', 'active'),
('Divya Menon',   'divya.menon@ims.com',   '9833445566', 'Interior Architect', 'Design',     70000, '2022-01-10', 'active'),
('Rohit Kumar',   'rohit.kumar@ims.com',   '9844556677', 'Site Supervisor',    'Execution',  55000, '2021-08-20', 'active'),
('Pooja Joshi',   'pooja.joshi@ims.com',   '9855667788', 'Accountant',         'Finance',    60000, '2020-11-05', 'active'),
('Amit Sinha',    'amit.sinha@ims.com',    '9866778899', 'Sales Executive',    'Sales',      50000, '2023-02-14', 'active'),
('Neha Gupta',    'neha.gupta@ims.com',    '9877889900', 'Junior Designer',    'Design',     40000, '2023-06-01', 'inactive');

-- =============================================================================
--  SAMPLE DATA — Projects
-- =============================================================================
INSERT INTO projects (name, client_id, status, start_date, end_date, budget, location, notes, assigned_employees) VALUES
('Sharma Residence Renovation',   1, 'ongoing',   '2025-01-15', '2025-06-30', 1400000, '14, MG Road, Bengaluru',       'Phase 1: living room & kitchen',                             '["Sneha Reddy","Rohit Kumar"]'),
('Mehta Living Room Makeover',    2, 'completed', '2024-08-01', '2024-11-30', 750000,  '7, Bandra West, Mumbai',        'Scandinavian theme with custom furniture',                   '["Divya Menon","Rohit Kumar"]'),
('Iyer Villa Full Interior',      3, 'pending',   '2025-06-01', '2026-01-31', 3200000, '22, Anna Nagar, Chennai',       'Complete villa from scratch — awaiting client sign-off',     '["Sneha Reddy","Karan Bose","Divya Menon"]'),
('Patel Office Fit-Out',          4, 'ongoing',   '2025-02-10', '2025-07-15', 1850000, '9, C-Scheme, Jaipur',           'Open office + 5 cabins + boardroom',                         '["Divya Menon","Rohit Kumar","Amit Sinha"]'),
('Nair Master Suite',             5, 'completed', '2024-10-01', '2025-01-15', 580000,  '45, Jubilee Hills, Hyderabad',  'Luxury bedroom + 2 bathrooms',                               '["Sneha Reddy"]'),
('Kapoor Contemporary Home',      6, 'pending',   '2025-07-01', '2026-03-31', 2400000, '3, South Extension, New Delhi', '4BHK + dedicated home office + study',                       '["Karan Bose","Divya Menon"]');

-- =============================================================================
--  SAMPLE DATA — Materials
-- =============================================================================
INSERT INTO materials (name, quantity, unit, unit_price, supplier_name, low_stock_threshold) VALUES
('Italian Marble Flooring',       240, 'sq ft',  350,  'Raj Stones Pvt Ltd',      50),
('Teak Wood Planks',              8,   'planks', 4500, 'Karnataka Timber Co',     15),
('Gypsum Board (12mm)',           180, 'sheets', 620,  'Saint-Gobain India',      30),
('Acrylic Emulsion Paint (White)',6,   'buckets',2800, 'Asian Paints Dealer',     10),
('Recessed LED Spotlights',       85,  'pcs',    450,  'Havells Lighting',        20),
('Designer Wallpaper Rolls',      22,  'rolls',  1800, 'Nilaya by Asian Paints',  5),
('Stainless Steel Hardware Set',  40,  'sets',   1200, 'Dorset Hardware',         10),
('Vinyl Flooring (Wood Finish)',  320, 'sq ft',  95,   'Floortek India',          60);

-- =============================================================================
--  SAMPLE DATA — Expenses
-- =============================================================================
INSERT INTO expenses (title, amount, category, project_id, date, description) VALUES
('Italian Marble — Sharma Residence', 84000, 'Materials',  1, '2025-01-20', '240 sq ft Italian marble for living + dining'),
('Labour — Mehta Project Completion', 95000, 'Labour',     2, '2024-11-25', 'Final labour billing for Mehta project'),
('Office Furniture Purchase',         38000, 'Office',  NULL, '2025-02-01', 'Work stations and chairs for design studio'),
('Site Transport — Patel Office',     12500, 'Transport',  4, '2025-02-15', 'Material delivery and crew transport'),
('CAD Software Subscription',         24000, 'Technology', NULL, '2025-01-05', 'Annual AutoCAD + 3ds Max subscription'),
('Electrical Fixtures — Sharma',      67000, 'Materials',  1, '2025-03-10', 'LED panels, switches, and wiring'),
('Gypsum & Plaster Work — Patel',     48000, 'Labour',     4, '2025-03-20', 'False ceiling and partition work'),
('Client Event — Portfolio Launch',   55000, 'Marketing', NULL, '2025-03-28', 'Venue + catering for portfolio showcase event');

-- =============================================================================
--  SAMPLE DATA — Invoices
-- =============================================================================
INSERT INTO invoices (invoice_number, client_id, project_id, amount, tax_rate, status, issue_date, due_date, notes) VALUES
('INV-2025-001', 1, 1, 700000, 18, 'paid',    '2025-01-31', '2025-02-28', '50% advance — Sharma Residence Phase 1'),
('INV-2025-002', 2, 2, 750000, 18, 'paid',    '2024-12-05', '2024-12-31', 'Final payment — Mehta Living Room'),
('INV-2025-003', 4, 4, 925000, 18, 'pending', '2025-02-28', '2025-03-31', '50% advance — Patel Office Fit-Out'),
('INV-2025-004', 5, 5, 580000, 18, 'paid',    '2025-01-20', '2025-02-15', 'Full payment — Nair Master Suite'),
('INV-2025-005', 1, 1, 700000, 18, 'pending', '2025-04-01', '2025-04-30', 'Balance payment — Sharma Residence'),
('INV-2025-006', 3, 3, 800000, 18, 'overdue', '2025-03-01', '2025-03-31', 'Advance — Iyer Villa (30%)');

-- =============================================================================
--  SAMPLE DATA — Activities
-- =============================================================================
INSERT INTO activities (type, description, created_at) VALUES
('client_added',     'New client Arjun Kapoor added for contemporary home project',         NOW() - INTERVAL '1 day'),
('invoice_created',  'Invoice INV-2025-006 generated for Ananya Iyer — ₹9,44,000',          NOW() - INTERVAL '2 days'),
('project_updated',  'Sharma Residence project updated: Phase 2 started',                   NOW() - INTERVAL '3 days'),
('payment_received', 'Payment received from Meera Nair — ₹6,84,400 (INV-2025-004)',         NOW() - INTERVAL '4 days'),
('material_added',   'New material added: Designer Wallpaper Rolls — 22 rolls in stock',    NOW() - INTERVAL '5 days'),
('expense_added',    'Marketing expense recorded: Client Portfolio Launch Event — ₹55,000', NOW() - INTERVAL '6 days'),
('project_created',  'New project created: Kapoor Contemporary Home',                       NOW() - INTERVAL '7 days'),
('employee_added',   'New employee Amit Sinha joined Sales department',                     NOW() - INTERVAL '8 days');

-- =============================================================================
--  VERIFICATION — Check row counts
-- =============================================================================
SELECT 'clients'    AS table_name, COUNT(*) AS rows FROM clients
UNION ALL SELECT 'employees',  COUNT(*) FROM employees
UNION ALL SELECT 'projects',   COUNT(*) FROM projects
UNION ALL SELECT 'materials',  COUNT(*) FROM materials
UNION ALL SELECT 'expenses',   COUNT(*) FROM expenses
UNION ALL SELECT 'invoices',   COUNT(*) FROM invoices
UNION ALL SELECT 'activities', COUNT(*) FROM activities
ORDER BY table_name;

-- Done!
SELECT '✅ IMS database setup complete! Open the app and log in with admin/admin123' AS status;
