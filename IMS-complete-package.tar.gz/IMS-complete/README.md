# IMS — Interior Management System
## Complete Package: Database + Source Code

---

## What's in this package

```
IMS-complete/
├── database/
│   └── ims_database.sql   ← Run this FIRST to set up PostgreSQL
├── artifacts/
│   ├── ims/               ← React frontend (Vite)
│   └── api-server/        ← Express API backend
├── lib/
│   ├── db/                ← Drizzle ORM schema + seed script
│   ├── api-spec/          ← OpenAPI specification
│   ├── api-client-react/  ← Generated React Query hooks
│   └── api-zod/           ← Generated Zod schemas
├── .env.example           ← Copy to .env and fill credentials
└── start.sh               ← One-command startup (Mac/Linux)
```

---

## Step 1 — Install required software

| Tool | Download |
|---|---|
| Node.js v20+ | https://nodejs.org |
| pnpm v9+ | Run: `npm install -g pnpm` |
| PostgreSQL v14+ | https://www.postgresql.org/download |

---

## Step 2 — Create the database

**Mac/Linux terminal:**
```bash
psql -U postgres -c "CREATE DATABASE ims;"
```

**Windows (Command Prompt as Administrator):**
```cmd
psql -U postgres -c "CREATE DATABASE ims;"
```

**pgAdmin GUI (easiest on Windows):**
1. Open pgAdmin → right-click Databases → Create → Database
2. Name it `ims` → Save

---

## Step 3 — Load tables + sample data

**Mac/Linux:**
```bash
psql -U postgres -d ims -f database/ims_database.sql
```

**Windows:**
```cmd
psql -U postgres -d ims -f database\ims_database.sql
```

**pgAdmin GUI:**
1. Click on the `ims` database → Query Tool
2. File → Open → select `database/ims_database.sql`
3. Press F5 to run

You will see a row count table confirming all data was loaded.

---

## Step 4 — Configure environment

```bash
pnpm install
cp .env.example .env
```

Edit `.env`:
```env
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/ims
```

No password? Use: `DATABASE_URL=postgresql://postgres@localhost:5432/ims`

---

## Step 5 — Run the app

**Mac/Linux (one command):**
```bash
chmod +x start.sh && ./start.sh
```

**Windows — open two terminals:**

Terminal 1 (API server):
```cmd
set PORT=8080
set DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/ims
pnpm --filter @workspace/api-server run dev
```

Terminal 2 (Frontend):
```cmd
set PORT=5173
set API_PORT=8080
pnpm --filter @workspace/ims run dev
```

Open **http://localhost:5173** — Login: `admin / admin123`

---

## Database Tables

| Table | Contents |
|---|---|
| `clients` | Name, phone, email, address, budget, requirements |
| `projects` | Name, status, dates, budget, assigned employees |
| `employees` | Name, role, department, salary, join date |
| `materials` | Inventory — quantity, unit price, low-stock threshold |
| `expenses` | Cost records by category, linked to projects |
| `invoices` | Billing with GST, status (paid/pending/overdue) |
| `activities` | Dashboard activity feed |

---

## How UI ↔ Database works

```
Browser → React App → /api/clients (POST)
              ↓
      Vite Proxy forwards to API Server (port 8080)
              ↓
      Express validates → Drizzle ORM
              ↓
      PostgreSQL: INSERT INTO clients ...
              ↓
      Response → React Query refreshes list
```

Every click in the UI writes directly to PostgreSQL in real time.

Check it yourself:
```sql
-- After adding a client in the UI:
SELECT * FROM clients ORDER BY created_at DESC LIMIT 1;
```

---

## Useful SQL Queries

```sql
-- All clients
SELECT id, name, phone, budget FROM clients;

-- Projects by status
SELECT status, COUNT(*) FROM projects GROUP BY status;

-- Revenue summary
SELECT status, COUNT(*), SUM(amount) FROM invoices GROUP BY status;

-- Low stock materials
SELECT name, quantity, low_stock_threshold
FROM materials WHERE quantity <= low_stock_threshold;

-- Recent expenses by category
SELECT category, SUM(amount) FROM expenses GROUP BY category ORDER BY SUM(amount) DESC;
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `psql: command not found` | Add PostgreSQL/bin to your system PATH |
| `Connection refused` | Start PostgreSQL service (brew services start postgresql on Mac) |
| `Database does not exist` | Run: `psql -U postgres -c "CREATE DATABASE ims;"` |
| Port already in use | Change PORT value in the run command |
| White screen | Make sure BOTH servers are running (API + frontend) |
