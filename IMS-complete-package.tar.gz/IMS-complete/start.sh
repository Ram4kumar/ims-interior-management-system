#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# IMS — Interior Management System
# Local development startup script
# Usage: ./start.sh
# ─────────────────────────────────────────────────────────────────────────────

set -e

# Load .env if present
if [ -f .env ]; then
  export $(grep -v '^#' .env | grep -v '^$' | xargs)
  echo "✓ Loaded .env"
fi

if [ -z "$DATABASE_URL" ]; then
  echo ""
  echo "❌  DATABASE_URL is not set."
  echo "    Copy .env.example to .env and fill in your PostgreSQL connection string."
  echo "    Example: DATABASE_URL=postgresql://postgres:password@localhost:5432/ims"
  echo ""
  exit 1
fi

# Kill background jobs on Ctrl+C
cleanup() {
  echo ""
  echo "Stopping servers…"
  kill 0
}
trap cleanup EXIT

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  IMS — Interior Management System"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  API server →  http://localhost:8080"
echo "  Frontend   →  http://localhost:5173"
echo ""
echo "  Login: admin / admin123   |   employee / emp123"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Start API server in background
PORT=8080 DATABASE_URL="$DATABASE_URL" \
  pnpm --filter @workspace/api-server run dev &

# Give API a moment to start
sleep 2

# Start frontend in foreground
PORT=5173 API_PORT=8080 \
  pnpm --filter @workspace/ims run dev
